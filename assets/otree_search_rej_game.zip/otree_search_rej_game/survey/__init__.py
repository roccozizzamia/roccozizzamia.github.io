from otree.api import *
from otree.models import player

doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'survey'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1



class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    pass
    #Survey questions:
    age = models.IntegerField(
        label = "Please enter your age",
        min=18,
        choices = [i for i in range(18,50)
                   ]
    )
    gender = models.StringField(
        label = "What is your gender?",
        intial = '--',
        choices = ['Female', 'Male', 'Other', 'Prefer not to say']
    )
    educ = models.StringField(
        label="What is your highest educational qualification?",
        intial='--',
        choices = ['less than matric', 'matric', 'matric with certificate', 'matric with diploma', 'bachelors degree', 'post-graduate degree']
    )
    race = models.StringField(
        label="What is your race?",
        intial='--',
        choices = ['black african', 'indian/asian', 'coloured', 'white', 'other']
    )


#### How did you search fields -- NOW
    search_how1 = models.BooleanField(
        intial=False,
        blank=True,
        label="Registered at an employment agency",
    )
    search_how2 = models.BooleanField(
        intial=False,
        blank=True,
        label="Enquired at workplaces, farms, factories, or called on other possible employers",
    )
    search_how3 = models.BooleanField(
        intial=False,
        blank=True,
        label="Placed advertisement (s)",
    )
    search_how4 = models.BooleanField(
        intial=False,
        blank=True,
        label="Answered advertisement (s)",
    )
    search_how5 = models.BooleanField(
        intial=False,
        blank=True,
        label="Searched through job advertisement (s) on the internet",
    )
    search_how6 = models.BooleanField(
        intial=False,
        blank=True,
        label="Sought assistance from relatives or friends",
    )
    search_how7 = models.BooleanField(
        intial=False,
        blank=True,
        label="Sent or dropped off my CV at prospective employers",
    )
    search_how8 = models.BooleanField(
        intial=False,
        blank=True,
        label="Waited at the side of the road",
    )
    search_how9 = models.BooleanField(
        intial=False,
        blank=True,
        label="Did something else",
    )

    #### How did you search fields -- 3 MONTHS
    search_how1_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Registered at an employment agency",
    )
    search_how2_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Enquired at workplaces, farms, factories, or called on other possible employers",
    )
    search_how3_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Placed advertisement (s)",
    )
    search_how4_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Answered advertisement (s)",
    )
    search_how5_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Searched through job advertisement (s) on the internet",
    )
    search_how6_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Sought assistance from relatives or friends",
    )
    search_how7_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Sent or dropped off my CV at prospective employers",
    )
    search_how8_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Waited at the side of the road",
    )
    search_how9_3m = models.BooleanField(
        intial=False,
        blank=True,
        label="Did something else",
    )

    #### How did you search fields -- 6 months
    search_how1_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Registered at an employment agency",
    )
    search_how2_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Enquired at workplaces, farms, factories, or called on other possible employers",
    )
    search_how3_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Placed advertisement (s)",
    )
    search_how4_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Answered advertisement (s)",
    )
    search_how5_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Searched through job advertisement (s) on the internet",
    )
    search_how6_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Sought assistance from relatives or friends",
    )
    search_how7_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Sent or dropped off my CV at prospective employers",
    )
    search_how8_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Waited at the side of the road",
    )
    search_how9_6m = models.BooleanField(
        intial=False,
        blank=True,
        label="Did something else",
    )

    ####


    start_job = models.IntegerField(
        label="How many months ago did you start your job?",
        intial='--',
        choices = [i for i in range(0,24)
                   ]
    )
    end_job = models.IntegerField(
        label="In how many months does your contract end?",
        intial='--',
        choices = [i for i in range(0,24)
                   ]
    )
    earn = models.IntegerField(
        label = "If you are comfortable saying, how much is your monthly take-home pay (after tax and deductions)?",
        blank=True,
        intial ='--',
        min=1000,
        max=50000
    )

    pres_activity = models.StringField(
        label = "What is your current employment status?",
        intial = '--',
        choices = ['Employed (permanent contract)', 'Employed (fixed-term contract)', 'Paid internship or learnership', 'In training / studying (unpaid)', 'Self-employed', 'Not employed, NOT looking for work', 'Not employed, looking for work'])

    emp_experience = models.IntegerField(
        label="How many months of work experience do you have (EXCLUDING your current job if you're employed)?",
        intial='--',
        choices=[i for i in range(0, 60)
                 ])

    dur_study = models.IntegerField(
        label="For how many months have you been in training / studying (unpaid)?",
        intial='--',
        choices = [i for i in range(0,60)
                   ]
    )

    dur_selfemp = models.IntegerField(
        label="For how many months have you been self-employed?",
        intial='--',
        choices = [i for i in range(0,60)
                   ]
    )

    dur_notemp = models.IntegerField(
        label="For how many months have you not been employed?",
        intial='--',
        choices = [i for i in range(0,60)
                   ]
    )

    dur_notsearch = models.IntegerField(
        label="For how many months have you not been searching for a job?",
        intial='--',
        choices = [i for i in range(0,60)
                   ]
    )

    pre_emp = models.StringField(
        label="What were you doing immediately before starting your job?",
        initial='---',
        choices=['Employed (permanent contract)', 'Employed (fixed-term contract)', 'Paid internship or learnership', 'In training / studying (unpaid)', 'Self-employed', 'Not employed, NOT looking for work', 'Not employed, looking for work']
    )

    pre_study = models.StringField(
        label="What were you doing immediately before starting your studies/training?",
        initial='---',
        choices=['Employed (permanent contract)', 'Employed (fixed-term contract)', 'Paid internship or learnership', 'In training / studying (unpaid)',
                 'Self-employed', 'Not employed, NOT looking for work', 'Not employed, looking for work']
    )

    pre_selfemp = models.StringField(
        label="What were you doing immediately before starting your own business?",
        initial='---',
        choices=['Employed (permanent contract)', 'Employed (fixed-term contract)', 'Paid internship or learnership', 'In training / studying (unpaid)',
                 'Self-employed', 'Not employed, NOT looking for work', 'Not employed, looking for work']
    )

    pre_notemp = models.StringField(
        label="You don't currently have a job. What were you doing before that?",
        initial='---',
        choices=['Employed (permanent contract)', 'Employed (fixed-term contract)', 'Paid internship or learnership', 'In training / studying (unpaid)',
                 'Self-employed', 'Not employed, NOT looking for work', 'Not employed, looking for work']
    )

    search_3m = models.StringField(
        label = "Were you searching for a job in the first quarter of this year (January to March)?",
        intial = '--',
        choices =['Yes', 'No', "I don't remember"]
    )
    search_now = models.StringField(
        label = "Are you currently searching for a job?",
        intial = '--',
        choices = ['Yes', 'No']
    )
    search_6m = models.StringField(
        label="Were you searching for a job in the second quarter of this year (April to June)?",
        intial='--',
        choices=['Yes', 'No', "I don't remember"]
    )

    search_future = models.StringField(
        label="Do you think you will be searching for a job in 3 months time -- in November this year?",
        intial='--',
        choices=['Yes', 'No', "I don't know"]
    )

    searchstop = models.StringField(
        label = "Did you start searching and then stop?",
        intial = '--',
        choices = ['Yes', 'No'])

    searchstop_reason = models.StringField(
        label = "Why did you start searching and then stop?",
        intial = '--',
        choices = ['Yes', 'No'])

    intensity_now = models.StringField(
        label = "<b>In the last week</b>, how many hours did you spend searching for a job? For example, looking for job-postings, sending out applications or designing a cv.",
        initial = '--',
        choices = ['less than 30 minutes', 'between 30 to 60 minutes', 'between 1 to 2 hours', 'between 2 to 4 hours', 'between 4 to 8 hours', 'over 8 hours', "I can't remember"]
    )
    intensity_3m = models.StringField(
        label="<b>In the second quarter of this year (April to June)</b> how many hours did you spend searching for a job in an average week?",
        initial='--',
        choices=['less than 30 minutes', 'between 30 to 60 minutes', 'between 1 to 2 hours', 'between 2 to 4 hours',
                 'between 4 to 8 hours', 'over 8 hours', "I can't remember"]
    )
    intensity_6m = models.StringField(
        label = "<b>In the first quarter of this year (January to March)</b> how many hours did you spend searching for a job in an average week?",
        initial = '--',
        choices = ['less than 30 minutes', 'between 30 to 60 minutes', 'between 1 to 2 hours', 'between 2 to 4 hours', 'between 4 to 8 hours', 'over 8 hours', "I can't remember"]
    )

    intensity_future = models.StringField(
        label = "<b>In 3 months time (November) how many hours a week will you spend searching for a job?",
        initial = '--',
        choices = ['less than 30 minutes', 'between 30 to 60 minutes', 'between 1 to 2 hours', 'between 2 to 4 hours', 'between 4 to 8 hours', 'over 8 hours', "I don't know"]
    )

    offers_6m = models.BooleanField(
        label="In the <b>first quarter of this year (January to March)</b>, did you get any job offers?",
        initial = False,

    )

    offers_3m = models.BooleanField(
        label="In the <b>second quarter of this year (April to June)</b>, did you get any job offers?",
        initial=False,

    )

    offers_1m = models.BooleanField(
        label="In <b>August this year</b>, did you get any job offers?",
        initial=False,

    )

    n_offers_6m = models.IntegerField(
        label="<b>In the first quarter of this year (January to March)</b>, how many job offers did you get?",
        intial='--',
        choices = [i for i in range(0,10)
                   ]
    )

    n_offers_3m = models.IntegerField(
        label="<b>In the second quarter of this year (April to June)</b>, how many job offers did you get?",
        intial='--',
        choices = [i for i in range(0,10)
                   ]
    )

    n_offers_1m = models.IntegerField(
        label="<b>In August this year</b>, how many job offers did you get?",
        intial='--',
        choices = [i for i in range(0,10)
                   ]
    )

    accept_6m = models.StringField(
        label="<b>In the first quarter of this year (January to March)</b>, did you accept any of the job offers that you received?",
        intial='--',
        choices=["Yes - I've already started the job", "Yes - I am waiting to start the job", "No - the wage was too low", "No - I didn't accept for another reason."
                 ]
    )

    accept_3m = models.StringField(
        label="<b>In the second quarter of this year (April to June)</b>, did you accept any of the job offers that you received?",
        intial='--',
        choices=["Yes - I've already started the job", "Yes - I am waiting to start the job", "No - the wage was too low", "No - I didn't accept for another reason."
                 ]
    )

    accept_1m = models.StringField(
        label="<b>In August this year</b>, did you accept any of the job offers that you received?",
        intial='--',
        choices=["Yes - I've already started the job", "Yes - I am waiting to start the job", "No - the wage was too low", "No - I didn't accept for another reason."
                 ]
    )




    selfeff_1 = models.IntegerField(
        label="I will be able to achieve most of the goals that I set for myself.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_2 = models.IntegerField(
        label="When facing difficult tasks, I am certain that I will accomplish them.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_3 = models.IntegerField(
        label="In general, I think that I can obtain outcomes that are important to me.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_4 = models.IntegerField(
        label="I believe I can succeed at almost any endeavor to which I set my mind.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_5 = models.IntegerField(
        label="I will be able to successfully overcome many challenges.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_6 = models.IntegerField(
        label="I am confident that I can perform effectively on many different tasks.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_7 = models.IntegerField(
        label="Compared to other people, I can do most tasks very well.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

    selfeff_8 = models.IntegerField(
        label="Even when things are tough, I can perform quite well.",
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5]
    )

#Expectations

    expect_1 = models.StringField(
        label="",
        widget=widgets.RadioSelect,
        choices=['Strongly agree with Statement 1', 'Agree with Statement 1', 'I feel the same about Statement 1 and 2', 'Agree with Statement 2', 'Strongly agree with Statement 2' ]
    )

    expect_2 = models.StringField(
        label="",
        widget=widgets.RadioSelect,
        choices=['Strongly agree with Statement 1', 'Agree with Statement 1', 'I feel the same about Statement 1 and 2', 'Agree with Statement 2', 'Strongly agree with Statement 2' ]
    )

    expect_3 = models.StringField(
        label="",
        widget=widgets.RadioSelect,
        choices=['Strongly agree with Statement 1', 'Agree with Statement 1', 'I feel the same about Statement 1 and 2', 'Agree with Statement 2', 'Strongly agree with Statement 2' ]
    )


    expect_4 = models.StringField(
        label="",
        widget=widgets.RadioSelect,
        choices=['Strongly agree with Statement 1', 'Agree with Statement 1', 'I feel the same about Statement 1 and 2', 'Agree with Statement 2', 'Strongly agree with Statement 2' ]
    )

#Ranking relative to peers

#Discouragement due to downward revision of job finding rates, or due to own ability
    expect_a = models.IntegerField(
        label="I feel optimistic that I will find a decent job if I keep searching.",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5]
    )

    expect_b = models.IntegerField(
        label="I struggle to motivate myself to search for jobs.",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5]
    )

    expect_c = models.IntegerField(
        label="Although searching for jobs is difficult, I am able to stay motivated.",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5]
    )

    expect_d = models.IntegerField(
        label="I didn't expect that finding a job would be so difficult.",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5]
    )

    expect_emp = models.IntegerField(
        label="Choose the point on the scale that represents <b>how likely it is that you will be employed one year from now:</b>",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5,6,7,8,9,10]
    )

    expect_perm = models.IntegerField(
        label="Choose the point on the scale that represents  <b>how likely it is that you will be offered a contract extension:</b>",
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5,6,7,8,9,10]
    )

    #Gambler's / hot hand fallacy
    gambler = models.IntegerField(
        label= 'Imagine you flipped a fair coin 5 times, and got heads five times. How likely is it that it will fall on heads when you flip it a 6th time?',
        widget=widgets.RadioSelect,
        choices=[1,2,3,4,5,6,7,8,9]
    )
    hothand = models.IntegerField(
        label = 'Imagine you ask a friend to guess a coin flip, and flip it five times. The results are as follows: heads, heads, tails, heads, tails. Your friend guesses right every time! How likely is it that she will get it right a 6th time?',
        widget=widgets.RadioSelect,
        choices=[1, 2, 3, 4, 5, 6, 7, 8, 9]
    )


    #Other
    email = models.StringField(blank=True, label = "If you would like to be sent a copy of this information please enter your email below (othewise just leave this blank):")
    prepop = models.StringField(label = "Code", intial = '--', choices = ['abc', 'bcd'])
    name = models.StringField(
        label="Please enter your name and surname",
    )
    phone_no = models.StringField(
        label="Please enter your cellphone number",
    )
    email_2 = models.StringField(
        label="Please enter your email address",
    )
    mobile_provider = models.StringField(
        label="Who is your network provider so we can send you the right airtime code?",
        initial='--',
        choices=['MTN', 'Cell-C', 'Vodacom', 'Telkom']
    )



# PAGES

class Consent(Page):
    form_model = "player"
    form_fields = ["email"]


class Details(Page):
    form_model = "player"
    form_fields = ["name", "email_2", "phone_no", "mobile_provider"]

class Survey1(Page):
    form_model = "player"
    form_fields = ['age', 'gender', 'race', 'educ', 'pres_activity', 'emp_experience']

class past_emp(Page):
    form_model = "player"
    form_fields = ['']

class Survey_emp(Page):
    form_model = "player"
    form_fields = ['start_job', 'end_job', 'earn', 'dur_notemp', 'dur_notsearch', 'dur_selfemp', 'dur_study', 'pre_emp', 'pre_study', 'pre_selfemp', 'pre_notemp']

    @staticmethod
    def get_form_fields(player):
        if player.pres_activity == 'Employed (permanent contract)':
            return ['start_job', 'earn', 'pre_emp']
        if player.pres_activity == 'Employed (fixed-term contract)':
            return ['start_job', 'end_job', 'earn', 'pre_emp']
        if player.pres_activity == 'Paid internship or learnership':
            return ['start_job', 'end_job', 'earn', 'pre_emp']
        if player.pres_activity == 'In training / studying (unpaid)':
            return ['dur_study', 'pre_study']
        if player.pres_activity == 'Self-employed':
            return ['dur_selfemp', 'pre_selfemp']
        if player.pres_activity == 'Not employed, NOT looking for work':
            return ['dur_notemp', 'pre_notemp']
        if player.pres_activity == 'Not employed, looking for work':
            return ['dur_notemp', 'pre_notemp']

class Survey2(Page):
    form_model = "player"
    form_fields = ["search_now", "search_3m", 'search_6m', 'search_future']

    @staticmethod
    def get_form_fields(player):
        if player.pres_activity == 'Not employed, NOT looking for work':
            return ['search_6m', 'search_3m', 'search_future']
        else:
            return ['search_6m', 'search_3m', 'search_now', 'search_future']


class Survey3(Page):
    #Note: Add option for "as not searching" and add warning message
    form_model = "player"
    form_fields = ['intensity_6m', 'offers_6m', 'intensity_3m', 'offers_3m', 'intensity_now', 'offers_1m', 'intensity_future']

    @staticmethod
    def get_form_fields(player):
        if player.search_now == 'Yes' and player.search_3m == 'Yes' and player.search_6m == 'Yes' and player.search_future == 'Yes':
            return ['intensity_6m', 'offers_6m',  'intensity_3m', 'offers_3m', 'intensity_now', 'offers_1m', 'intensity_future']
        if player.search_now == 'No' and player.search_3m == 'Yes' and player.search_6m == 'Yes' and player.search_future == 'Yes':
            return ['intensity_6m', 'offers_6m', 'intensity_3m', 'offers_3m',  'intensity_future']
        if player.search_now == 'Yes' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and player.search_6m == 'Yes' and player.search_future == 'Yes':
            return ['intensity_6m', 'offers_6m', 'intensity_now', 'offers_1m',  'intensity_future']
        if player.search_now == 'Yes' and player.search_3m == 'Yes' and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and player.search_future == 'Yes':
            return ['intensity_3m', 'offers_3m', 'intensity_now', 'offers_1m', 'intensity_future']
        if player.search_now == 'Yes' and player.search_3m == 'Yes' and player.search_6m == 'Yes' and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_6m', 'offers_6m', 'intensity_3m', 'offers_3m', 'intensity_now', 'offers_1m']
        if player.search_now == 'No' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and player.search_6m == 'Yes' and player.search_future == 'Yes':
            return ['intensity_6m', 'offers_6m', 'intensity_future']
        if player.search_now == 'Yes' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and player.search_future == 'Yes':
            return ['intensity_now', 'offers_1m',  'intensity_future']
        if player.search_now == 'Yes' and player.search_3m == 'Yes' and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_3m', 'offers_3m', 'intensity_now', 'offers_1m']
        if player.search_now == 'No' and player.search_3m == 'Yes' and player.search_6m == 'Yes' and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_6m', 'offers_6m', 'intensity_3m', 'offers_3m']
        if player.search_now == 'No' and player.search_3m == 'Yes' and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and player.search_future == 'Yes':
            return ['intensity_3m', 'offers_3m', 'intensity_future']
        if player.search_now == 'Yes' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and player.search_6m == 'Yes' and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_6m', 'offers_6m', 'intensity_now', 'offers_1m']
        if player.search_now == 'No' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and player.search_future == 'Yes':
            return ['intensity_future']
        if player.search_now == 'No' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and player.search_6m == 'Yes' and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_6m', 'offers_6m']
        if player.search_now == 'No' and player.search_3m == 'Yes' and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_3m', 'offers_3m']
        if player.search_now == 'Yes' and (player.search_3m == 'No' or player.search_3m == "I don't remember") and (player.search_6m == 'No' or player.search_6m == "I don't remember")  and (player.search_future == 'No' or player.search_future == "I don't know"):
            return ['intensity_now', 'offers_1m']

    @staticmethod
    def is_displayed(player: Player):
        return player.search_now == 'Yes' or player.search_3m == 'Yes' or player.search_6m == 'Yes' or player.search_future == 'Yes'

class offers(Page):
    form_model = 'player'
    form_fields = ['n_offers_1m', 'accept_1m', 'n_offers_3m', 'accept_3m', 'n_offers_6m', 'accept_6m']

    @staticmethod
    def get_form_fields(player):
        if player.offers_1m == True and player.offers_3m == True and player.offers_6m == True:
            return ['n_offers_6m', 'accept_6m', 'n_offers_3m', 'accept_3m', 'n_offers_1m', 'accept_1m']
        if player.offers_1m == True and player.offers_3m == False and player.offers_6m == True:
            return [ 'n_offers_6m', 'accept_6m', 'n_offers_1m', 'accept_1m', ]
        if player.offers_1m == True and player.offers_3m == True and player.offers_6m == False:
            return ['n_offers_3m', 'accept_3m', 'n_offers_1m', 'accept_1m', ]
        if player.offers_1m == False and player.offers_3m == True and player.offers_6m == True:
            return ['n_offers_6m', 'accept_6m', 'n_offers_3m', 'accept_3m']
        if player.offers_1m == True and player.offers_3m == False and player.offers_6m == False:
            return ['n_offers_1m', 'accept_1m']
        if player.offers_1m == False and player.offers_3m == False and player.offers_6m == True:
            return ['n_offers_6m', 'accept_6m' ]
        if player.offers_1m == False and player.offers_3m == True and player.offers_6m == False:
            return ['n_offers_3m', 'accept_3m']

    @staticmethod
    def is_displayed(player: Player):
        return player.field_maybe_none('offers_1m') == True or player.field_maybe_none('offers_3m') == True or player.field_maybe_none('offers_6m') == True

class searchhow_now(Page):
    form_model = 'player'
    form_fields = ['search_how1', 'search_how2', 'search_how3', 'search_how4', 'search_how5', 'search_how6', 'search_how7', 'search_how8', 'search_how9']

    @staticmethod
    def is_displayed(player: Player):
        return player.search_now == 'Yes'

class searchhow_3m(Page):
    form_model = 'player'
    form_fields = ['search_how1_3m', 'search_how2_3m', 'search_how3_3m', 'search_how4_3m', 'search_how5_3m', 'search_how6_3m', 'search_how7_3m', 'search_how8_3m', 'search_how9_3m']

    @staticmethod
    def is_displayed(player: Player):
        return player.search_3m == 'Yes'

class searchhow_6m(Page):
    form_model = 'player'
    form_fields = ['search_how1_6m', 'search_how2_6m', 'search_how3_6m', 'search_how4_6m', 'search_how5_6m', 'search_how6_6m', 'search_how7_6m', 'search_how8_6m', 'search_how9_6m']

    @staticmethod
    def is_displayed(player: Player):
        return player.search_6m == 'Yes'

class Survey4(Page):
    form_model = "player"
    @staticmethod
    def get_form_fields(player):
        if player.pres_activity == 'Employed (permanent contract)':
            return ["expect_emp"]
        elif player.pres_activity == 'Employed (fixed-term contract)' or player.pres_activity == 'Paid internship or learnership':
            return ["expect_emp", "expect_perm"]

    @staticmethod
    def is_displayed(player: Player):
        return player.pres_activity == 'Employed (permanent contract)' or player.pres_activity == 'Employed (fixed-term contract)' or player.pres_activity == 'Paid internship or learnership'


class selfeff(Page):
    form_model = 'player'
    form_fields = ['selfeff_1', 'selfeff_2', 'selfeff_3', 'selfeff_4', 'selfeff_5', 'selfeff_6', 'selfeff_7','selfeff_8' ]


class expect(Page):
    form_model = 'player'
    form_fields = ['expect_1', 'expect_2', 'expect_3', 'expect_4' ]

class expect_2(Page):
    form_model = 'player'
    form_fields = ['expect_a', 'expect_b', 'expect_c',  'expect_d']

class Gambler_HH(Page):
    form_model = 'player'
    form_fields = ['gambler', 'hothand']

class thanks(Page):
    pass

page_sequence = [Details, Survey1, Survey_emp, Survey2, Survey3, offers, searchhow_now, searchhow_3m, searchhow_6m, Survey4, Gambler_HH, expect, expect_2, selfeff]
#page_sequence = [playercode, nameandnumber, Consent, Details, Survey1, Survey_emp, Survey2, Survey3, searchhow_now, searchhow_3m, searchhow_6m, applications, offers, Survey4, Gambler_HH, expect, expect_2, selfeff, thanks]


