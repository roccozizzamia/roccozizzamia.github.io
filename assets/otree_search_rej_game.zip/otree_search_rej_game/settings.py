import importlib.util
from os import environ

SESSION_CONFIGS = [
    dict(
        name="survey",
        display_name="Survey",
        num_demo_participants=2,
        app_sequence=["survey"],
    ),
    dict(
        name="timepref",
        display_name="Time preferences",
        num_demo_participants=2,
        app_sequence=["timepref"],
    ),
    dict(
        name="otime",
        display_name="Time CTB",
        num_demo_participants=2,
        app_sequence=["otime"],
    ),
    dict(
        name="snorej",
        display_name="Search without rejection",
        num_demo_participants=2,
        app_sequence=["snorej"],
    ),
    dict(
        name="intro",
        display_name="Introduction",
        num_demo_participants=2,
        app_sequence=["intro"],
    ),
    dict(
        name="prac",
        display_name="Sliders, practice",
        num_demo_participants=3,
        app_sequence=["prac"],
    ),
    dict(
        name="search",
        display_name="Sliders, favours searching",
        num_demo_participants=2,
        app_sequence=["search"],
    ),
    dict(
        name="stay",
        display_name="Sliders, favours staying",
        num_demo_participants=2,
        app_sequence=["stay"],
    ),
    dict(
        name="mr",
        display_name="Sliders, morerej",
        num_demo_participants=2,
        app_sequence=["mr"],
    ),
    dict(
        name="po",
        display_name="Labour market game - peer outcomes",
        num_demo_participants=4,
        app_sequence=["po"],
    ),
    dict(
        name="pe",
        display_name="Labour market game - peer effort",
        num_demo_participants=4,
        app_sequence=["pe"],
    ),
    dict(
        name="fullgame",
        display_name="Full game",
        num_demo_participants=2,
        app_sequence=["intro", "prac", "snorej", "search", "stay", "mr", "survey", "otime"],

    ),
]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.00,
    participation_fee=80.00,
    doc="",
    return_search_searchcond = 55,
    return_stay_searchcond = 50,
    return_search_staycond=55,
    return_stay_staycond=50
)

PARTICIPANT_FIELDS = ['is_dropout', 'session_payoff', 'r1_po', 'r2_po', 'r3_po', 'r4_po', 'r5_po', 'r6_po']

SESSION_FIELDS = ['params']

# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = "en"

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = "ZAR"
USE_POINTS = False

ADMIN_USERNAME = "admin"
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get("OTREE_ADMIN_PASSWORD")

DEMO_PAGE_TITLE = "Labour market game"
DEMO_PAGE_INTRO_HTML = ""

SECRET_KEY = "2015765205890"


ROOMS = [
    dict(
        name='room1',
        display_name='Room 1 - CapaCiTi-Oxford study',
        participant_label_file='_rooms/room1.txt',
        use_secure_urls=False
    ),
    dict(
        name='room2',
        display_name='Room 2 - CapaCiTi-Oxford study',
        participant_label_file='_rooms/room2.txt',
        use_secure_urls=False
    ),
    dict(
        name='room3',
        display_name='Room 3 - CapaCiTi-Oxford study',
        participant_label_file='_rooms/room3.txt',
        use_secure_urls=False
    ),
    dict(
        name='room4',
        display_name='Room 4 - CapaCiTi-Oxford study',
        participant_label_file='_rooms/room4.txt',
        use_secure_urls=False
    ),
    dict(
        name='room5',
        display_name='Room 5 - CapaCiTi-Oxford study',
        participant_label_file='_rooms/room5.txt',
        use_secure_urls=False
    ),

]


# adjustments for testing
# generating session configs for all varieties of features
import sys


if sys.argv[1] == 'test':
    MAX_ITERATIONS = 5
    FREEZE_TIME = 0.1
    TRIAL_PAUSE = 0.2
    TRIAL_TIMEOUT = 0.3

    SESSION_CONFIGS = [
        dict(
            name=f"testing_sliders",
            num_demo_participants=1,
            app_sequence=['sliders'],
            trial_delay=TRIAL_PAUSE,
            retry_delay=FREEZE_TIME,
            num_sliders=3,
            attempts_per_slider=3,
        ),
    ]
    for task in ['decoding', 'matrix', 'transcription']:
        SESSION_CONFIGS.extend(
            [
                dict(
                    name=f"testing_{task}_defaults",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                ),
                dict(
                    name=f"testing_{task}_retrying",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    attempts_per_puzzle=5,
                ),
                dict(
                    name=f"testing_{task}_limited",
                    num_demo_participants=1,
                    app_sequence=['real_effort'],
                    puzzle_delay=TRIAL_PAUSE,
                    retry_delay=FREEZE_TIME,
                    max_iterations=MAX_ITERATIONS,
                ),
            ]
        )

INSTALLED_APPS = [
    'otree',
    'otreeutils'    # this is important -- otherwise otreeutils' templates and static files won't be accessible
]

if importlib.util.find_spec('pandas'):
    ROOT_URLCONF = 'otreeutils_example3_market.urls'