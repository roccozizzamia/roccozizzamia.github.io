# Search and rejection

This OTree app contains several games in which players repeatedly make choices between "searching for a new job" or "focusing on their current job". What choice players make determines how frequently they receive information on their failure to receive a payoff. 
Regardless of the choice, players are required to perform a real effort task (here using the [Gill and Prowse slider task](https://github.com/chkgk/slider_task)), which determines the likelihood of receiving a payout. 
The games described below are variants of the same basic game, in which various key parameters relevant to identifying a "rejection effect" are experimentally varied. 

## Apps

**Intro**: `intro` introduces the game and explains the rules to participants.

**Practice session**: `prac` provides participants an opprtunity to practice the slider task, and understand how outcomes are determined by luck and effort. 

**Games**:
- `stay`: Players face a monetary incentive to "focus on their current job" relative to "search for a new job".
- `search`: Players face a monetary incentive to "search for a new job" relative to "focus on their current job".
- `mr`: Players face a monetary incentive to "search for a new job" relative to "focus on their current job", but are exposed to twice as much information on failure as in the `search` game. 
- `snorej`: Players face a monetary incentive to "search for a new job" relative to "focus on their current job", but are exposed to no information on failure until the end of the game. 

**Survey modules**:
- `survey`: A survey module focusing on demographics and labour market characteristics.  
- `otime`: Measures time preferences using this [OTree app](https://github.com/rose-m/otime).

Anti-cheating and anti-scripting protection:
- the puzzles are generated as images, no solution data is even revealed into browser
- validation of answers on server side
- `puzzle_delay`: minimal delay between iterations
- `retry_delay`: minimal delay before next retry after wrong answer 

Configurable features, via session config:
- `participation_fee`: Show up fee
- `return_search_searchcond`: Monetary incentive to searching in the "search" condition
- `return_stay_searchcond`: Monetary incentive to not searching in the "search" condition
- `return_search_staycond`: Monetary incentive to searching in the "stay" condition
- `return_stay_staycond`: Monetary incentive to not searching in the "stay" condition

For sliders:
- `num_sliders`: total number of sliders
- `num_columns`: number of columns in grid

