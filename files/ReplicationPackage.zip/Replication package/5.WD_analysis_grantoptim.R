
packages <- c("tidyverse", "foreign", "xtable")
invisible(lapply(packages, library, character.only = TRUE))

##Add working directory here
 setwd("C:/Users/ihsaa/Dropbox/Policy_response_corona/WDpaper_analysis/")
# setwd("C:/Users/joshb/Dropbox/projects/Policy_response_corona/WDpaper_analysis/")

##LOAD DATA 
pov <- read.dta("povoptim.dta")

#IMPOSE SHOCK (75% SIMULATED), and set to 0 if negative
pov <- pov %>% mutate(hhincome_no= hhincome - .75*hhinformal_income) %>%
              mutate(hhincome_no= ifelse(hhincome_no<0, 0, hhincome_no))

# For precision later, get actual numbers of recipients (outside the fn)   JBcheck
csgpop_outfn <- as.numeric(pov %>% filter(hhtag==1) %>% summarize(sum(hhcsg_children*fwgt)))
cogpop_outfn <- as.numeric(pov %>% filter(hhtag==1) %>% summarize(sum(hhnum_cog*fwgt)))
std_csgmax = 8e9/csgpop_outfn 


#MINIMIZE OVER POVERTY GAP ##############################################################


sim_pov <- function(csgamt, data=pov, pc= hhsizer, noninfwgt= 1, budget=8e9, fgt=1, sharing=1) {
  
  # For precision purposes, create recipient counts inside the fn  JBcheck
  csgpop_infn <- as.numeric(data %>% filter(hhtag==1) %>% summarize(sum(hhcsg_children*fwgt)))
  cogpop_infn <- as.numeric(data %>% filter(hhtag==1) %>% summarize(sum(hhnum_cog*fwgt)))
  
  #Calculate value of cog conditional on budget and value of csg
  cogamt <- (budget- (csgpop_infn*csgamt))/cogpop_infn    
  
  #Clean up: Apply equiv/per capita and filter for group  #JBcheck I think i understand this but come back
  data$pc <- eval(substitute(pc), data)
  
  #Calculate new income and gap conditional on sharing    #JBcheck small syntax thing, removed inconsistent data$ refs unnecessary for dplyr
  if (sharing==1) data <- data %>% mutate(hhnewinc= hhincome_no + csgamt*hhcsg_children + cogamt*hhnum_cog)
  else if (sharing==0) data <- data %>% mutate(hhnewinc= hhincome_no + csgamt*csg_children*pc + cogamt*cog_dummy*pc)
  data <- data %>% mutate(gap= (1265-(hhnewinc/pc))/1265) 
                          

  #Adjust gap to fgt power (1=gap, 2=gap^2)
  data <- data %>% mutate(gap_final= ifelse(gap<0, 0, gap^fgt))
  
  #Reweight to account for assigned weight on non-informal HHs
  data <- data %>% mutate(wgt= ifelse(hhinformal==1, fwgt, noninfwgt*fwgt))
  
  #Mean weighted gap poverty rate, weighted by survey * assigned
  meangap <- data %>% summarize(gap_grp= weighted.mean(gap_final*100, wgt))

  return(meangap)  
}


#MINIMIZE OVER GAP

#All, per capita
csgamt.all <- optim(par= 318, fn= sim_pov, data=pov, method='L-BFGS-B', lower=0, upper=std_csgmax)

#All, equiv
csgamt.equiv <- optim(par= 318, fn= sim_pov, data=pov, pc= hhsizerequiv, 
                      method='L-BFGS-B', lower=0, upper=std_csgmax)

#All, per capita, no sharing
csgamt.share <- optim(par= 318, fn= sim_pov, data=pov, sharing=0, method='L-BFGS-B', lower=0, upper=std_csgmax)

#Informal members, per capita
csgamt.inf <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= 0, 
                    method='L-BFGS-B', lower=0, upper=std_csgmax)

#Informal members, equiv
csgamt.infequiv <- optim(par= 318, fn= sim_pov, data=pov, pc= hhsizerequiv, noninfwgt= 0,
                    method='L-BFGS-B', lower=0, upper=std_csgmax)

#informal members, per capita, no sharing
csgamt.infshare <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= 0, sharing=0, method='L-BFGS-B', lower=0, upper=std_csgmax)





#REPEAT FOR GAP^2

#All, per capita
csgamt.all2 <- optim(par= 318, fn= sim_pov, data=pov, fgt=2, method='L-BFGS-B', lower=0, upper=std_csgmax)

#All, equiv
csgamt.equiv2 <- optim(par= 318, fn= sim_pov, data=pov, pc= hhsizerequiv, fgt=2, 
                      method='L-BFGS-B', lower=0, upper=std_csgmax)

#All, per capita, no sharing
csgamt.share2 <- optim(par= 318, fn= sim_pov, data=pov, fgt=2, sharing=0, method='L-BFGS-B', lower=0, upper=std_csgmax)

#Informal members, per capita
csgamt.inf2 <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= 0, fgt=2,
                    method='L-BFGS-B', lower=0, upper=std_csgmax)

#Informal members, equiv
csgamt.infequiv2 <- optim(par= 318, fn= sim_pov, data=pov, pc= hhsizerequiv, noninfwgt= 0, fgt=2,
                         method='L-BFGS-B', lower=0, upper=std_csgmax)

#informal members, per capita, no sharing
csgamt.infshare2 <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= 0, fgt=2, sharing=0, method='L-BFGS-B', lower=0, upper=std_csgmax)





#REPORT AS TABLE 
optima <- as.data.frame(rbind(c('All', 'per capita', csgamt.all$par, csgamt.all$value, csgamt.all2$par, csgamt.all2$value),
                              c('All', 'equiv', csgamt.equiv$par, csgamt.equiv$value, csgamt.equiv2$par, csgamt.equiv2$value),
                              c('All', 'no sharing', csgamt.share$par, csgamt.share$value, csgamt.share2$par, csgamt.share2$value),
                              c('informal', 'per capita', csgamt.inf$par, csgamt.inf$value, csgamt.inf2$par, csgamt.inf2$value),
                              c('informal', 'equiv', csgamt.infequiv$par, csgamt.infequiv$value, csgamt.infequiv2$par, csgamt.infequiv2$value),
                              c('informal', 'no sharing', csgamt.infshare$par, csgamt.infshare$value, csgamt.infshare2$par, csgamt.infshare2$value)))
optima <- optima %>% mutate(group= V1, scaling= V2, 
                            csg.val= round(as.numeric(as.character(V3))), 
                            pov.gap= round(as.numeric(as.character(V4))),
                            csg.val2= round(as.numeric(as.character(V5))), 
                            pov.gap2= round(as.numeric(as.character(V6)))) %>% 
  select(group,scaling,csg.val,pov.gap,csg.val2,pov.gap2) %>%
  mutate(cog.val= round((8e9-(csgpop_outfn*csg.val))/cogpop_outfn), cog.val2= round((8e9-(csgpop_outfn*csg.val2))/cogpop_outfn))  # JBcheck small precision adjustment
  
optima <- optima %>% select(group, scaling, csg.val, cog.val, pov.gap, csg.val2, cog.val2, pov.gap2) %>% t()
optima



print(xtable(optima, type = "latex"), file = "optima.tex")



#RESULTS FOR DIFFERENT BUDGETS ##############################################################


#Function which runs through different budget values
budgets.pov <- function(budgets=8e9) {
  csgmax <- budgets/csgpop_outfn    # JBcheck precision
  csg.amt <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= 0, method='L-BFGS-B', 
        lower=0, upper=csgmax, budget= budgets)
  cog.amt <- (budgets-csgpop_outfn*csg.amt$par)/cogpop_outfn    #JBcheck precision 
  return(c(budgets, csg.amt$par, csg.amt$value, cog.amt))
}

#Apply to range of budget values
budgets <- array(c(seq(from=1e9, to=30e9, by=1e9)))
budgets.optima <- apply(X=budgets,MARGIN=1,FUN=budgets.pov)    

budgets.optima <-  budgets.optima %>% t() %>% as.data.frame() %>%
  rename(budget=V1, csgamt=V2, povgap=V3, cogamt=V4) 
write.dta(budgets.optima, file="budgets_optima.dta")



#RESULTS FOR DIFFERENT NON-INF WEIGHTS ##############################################################


#Function which runs through different weight values
noninfwgt.pov <- function(noninfwgts=1) {
  csg.amt <- optim(par= 318, fn= sim_pov, data=pov, noninfwgt= noninfwgts, method='L-BFGS-B', 
                   lower=0, upper=std_csgmax)
  cog.amt <- (8e9-csgpop_outfn*csg.amt$par)/cogpop_outfn 
  return(c(noninfwgts, csg.amt$par, csg.amt$value, cog.amt))
}

#Apply to range of non-informal weights
noninfwgts <- array(c(seq(from=0, to=1, by=0.1)))
noninfwgt.optima <- apply(X=noninfwgts,MARGIN=1,FUN=noninfwgt.pov)   

noninfwgt.optima <-  noninfwgt.optima %>% t() %>% as.data.frame() %>%
  rename(noninfwgt=V1, csgamt=V2, povgap=V3, cogamt=V4) 
write.dta(noninfwgt.optima, file="noninfwgt_optima.dta")

